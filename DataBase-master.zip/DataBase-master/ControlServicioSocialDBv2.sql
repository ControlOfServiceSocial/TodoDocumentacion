USE [master]
GO
/****** Object:  Database [ControlServicioSocialDB]    Script Date: 30/10/2023 03:34:51 ******/
CREATE DATABASE [ControlServicioSocialDB]
GO
USE [ControlServicioSocialDB]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CCarreraEstudiante](
	[IdCarreraEstudiante] [int] IDENTITY(1,1) NOT NULL,
	[IdCarrera] [int] NOT NULL,
	[IdEstudiante] [int] NOT NULL,
 CONSTRAINT [PK_CarreraEstudiante] PRIMARY KEY CLUSTERED 
(
	[IdCarreraEstudiante] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CCertificado]    Script Date: 30/10/2023 03:34:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CCertificado](
	[IdCertificado] [int] IDENTITY(1,1) NOT NULL,
	[DocumentoCertificado] [varbinary](max) NULL,
	[IdEstudiante] [int] NULL,
	[TituloCertificado] [nchar](10) NULL,
	[CargaHoraria] [date] NULL,
 CONSTRAINT [PK__Certific__3214EC07DB8C706B] PRIMARY KEY CLUSTERED 
(
	[IdCertificado] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CEstudiante]    Script Date: 30/10/2023 03:34:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CEstudiante](
	[IdEstudiante] [int] IDENTITY(1,1) NOT NULL,
	[NombreEstudiante] [varchar](100) NOT NULL,
	[ApellidoPaternoEstudiante] [varchar](100) NOT NULL,
	[ApellidoMaternoEstudiante] [varchar](100) NULL,
	[EmailEstudiante] [varchar](100) NOT NULL,
	[TelefonoEstudiante] [varchar](20) NULL,
	[FechaRegistroEstudiante] [datetime] NULL,
	[FechaActualizacion] [datetime] NULL,
 CONSTRAINT [PK_CEstudiante] PRIMARY KEY CLUSTERED 
(
	[IdEstudiante] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CFacultad]    Script Date: 30/10/2023 03:34:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CFacultad](
	[IdFacultad] [int] IDENTITY(1,1) NOT NULL,
	[NombreFacultad] [varchar](50) NOT NULL,
	[IdEstudiante] [int] NULL,
	[IdSede] [int] NULL,
 CONSTRAINT [PK__Facultad__3214EC0796A873F7] PRIMARY KEY CLUSTERED 
(
	[IdFacultad] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CProyecto]    Script Date: 30/10/2023 03:34:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CProyecto](
	[IdProyecto] [int] IDENTITY(1,1) NOT NULL,
	[NombreProyecto] [varchar](100) NOT NULL,
	[DescripcionProyecto] [varchar](250) NOT NULL,
	[UbicacionProyecto] [varchar](100) NOT NULL,
	[EstadoProyecto] [tinyint] NULL,
	[ImagenProyecto] [varchar](max) NULL,
	[HorasEstimadas] [tinyint] NOT NULL,
	[FechaInicioProyecto] [date] NULL,
	[FechaFinProyecto] [date] NULL,
	[FechaCreacionProyecto] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[IdProyecto] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CProyectoEstudiante]    Script Date: 30/10/2023 03:34:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CProyectoEstudiante](
	[IdProyectoEstudiante] [int] IDENTITY(1,1) NOT NULL,
	[IdProyecto] [int] NOT NULL,
	[IdEstudiante] [int] NOT NULL,
	[HoraAcumulada] [int] NULL,
	[HoraInicio] [datetime] NULL,
	[HoraFinal] [datetime] NULL,
	[LatitudInicial] [varchar](50) NULL,
	[LongitudInicial] [varchar](50) NULL,
	[LatitudFinal] [varchar](50) NULL,
	[LongitudFinal] [varchar](50) NULL,
 CONSTRAINT [PK_ProyectoEstudiante] PRIMARY KEY CLUSTERED 
(
	[IdProyectoEstudiante] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CSede]    Script Date: 30/10/2023 03:34:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CSede](
	[IdSede] [int] IDENTITY(1,1) NOT NULL,
	[NombreSede] [varchar](50) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[IdSede] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[CProyecto] ON 

INSERT [dbo].[CProyecto] ([IdProyecto], [NombreProyecto], [DescripcionProyecto], [UbicacionProyecto], [EstadoProyecto], [ImagenProyecto], [HorasEstimadas], [FechaInicioProyecto], [FechaFinProyecto], [FechaCreacionProyecto]) VALUES (1, N'Proyecto 1', N'qweqweqwe', N'calle A numero 2', 2, N'../../Imagenes/ProyectoHomePgae.png', 4, CAST(N'2023-10-10' AS Date), CAST(N'2023-10-14' AS Date), CAST(N'2023-10-11T00:00:00.000' AS DateTime))
INSERT [dbo].[CProyecto] ([IdProyecto], [NombreProyecto], [DescripcionProyecto], [UbicacionProyecto], [EstadoProyecto], [ImagenProyecto], [HorasEstimadas], [FechaInicioProyecto], [FechaFinProyecto], [FechaCreacionProyecto]) VALUES (2, N'Proyecto 1', N'qweqweqwe', N'calle A numero 2', 2, N'../../Imagenes/ProyectoHomePgae.png', 4, CAST(N'2023-10-10' AS Date), CAST(N'2023-10-14' AS Date), CAST(N'2023-10-11T00:00:00.000' AS DateTime))
INSERT [dbo].[CProyecto] ([IdProyecto], [NombreProyecto], [DescripcionProyecto], [UbicacionProyecto], [EstadoProyecto], [ImagenProyecto], [HorasEstimadas], [FechaInicioProyecto], [FechaFinProyecto], [FechaCreacionProyecto]) VALUES (3, N'456', N'qweqweqwe', N'calle A numero 2', 2, N'../../Imagenes/Proyecto/HomePgae.png', 4, CAST(N'2023-10-04' AS Date), CAST(N'2023-10-14' AS Date), CAST(N'2023-10-05T00:00:00.000' AS DateTime))
INSERT [dbo].[CProyecto] ([IdProyecto], [NombreProyecto], [DescripcionProyecto], [UbicacionProyecto], [EstadoProyecto], [ImagenProyecto], [HorasEstimadas], [FechaInicioProyecto], [FechaFinProyecto], [FechaCreacionProyecto]) VALUES (4, N'proyecto 2', N'qwewqeqw', N'calle A numero 2', 2, N'../../Imagenes/Proyecto/proyecto 2', 5, CAST(N'2023-10-19' AS Date), CAST(N'2023-10-14' AS Date), CAST(N'2023-10-05T00:00:00.000' AS DateTime))
INSERT [dbo].[CProyecto] ([IdProyecto], [NombreProyecto], [DescripcionProyecto], [UbicacionProyecto], [EstadoProyecto], [ImagenProyecto], [HorasEstimadas], [FechaInicioProyecto], [FechaFinProyecto], [FechaCreacionProyecto]) VALUES (5, N'Proyecto 1', N'qweqweqwe', N'calle A numero 2', 2, N'../../Imagenes/Proyecto/Proyecto 1', 4, CAST(N'2023-10-25' AS Date), CAST(N'2023-10-27' AS Date), CAST(N'2023-10-26T00:00:00.000' AS DateTime))
SET IDENTITY_INSERT [dbo].[CProyecto] OFF
GO
ALTER TABLE [dbo].[CProyecto]  WITH CHECK ADD  CONSTRAINT [CHK_EstadoProyecto] CHECK  (([EstadoProyecto]=(3) OR [EstadoProyecto]=(2) OR [EstadoProyecto]=(1)))
GO
ALTER TABLE [dbo].[CProyecto] CHECK CONSTRAINT [CHK_EstadoProyecto]
GO
/****** Object:  StoredProcedure [dbo].[CEstudiante_O]    Script Date: 30/10/2023 03:34:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[CEstudiante_O]

AS 

BEGIN

	SELECT IdEstudiante, NombreEstudiante, ApellidoPaternoEstudiante, ApellidoMaternoEstudiante, EmailEstudiante, TelefonoEstudiante, FechaRegistroEstudiante, FechaActualizacion

	FROM CEstudiante

END
GO
/****** Object:  StoredProcedure [dbo].[CProyecto_I]    Script Date: 30/10/2023 03:34:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[CProyecto_I]
(
    @NombreProyecto varchar(100),
    @DescripcionProyecto varchar(250),
    @UbicacionProyecto varchar(100),
    @EstadoProyecto tinyint,
    @ImagenProyecto varchar(MAX),
    @HorasEstimadas tinyint,
    @FechaInicioProyecto date,
    @FechaFinProyecto date,
    @FechaCreacionProyecto datetime
)
AS
BEGIN
    INSERT INTO CProyecto (NombreProyecto, DescripcionProyecto, UbicacionProyecto, EstadoProyecto, ImagenProyecto, HorasEstimadas, FechaInicioProyecto, FechaFinProyecto, FechaCreacionProyecto)
    VALUES (@NombreProyecto, @DescripcionProyecto, @UbicacionProyecto, @EstadoProyecto, @ImagenProyecto, @HorasEstimadas, @FechaInicioProyecto, @FechaFinProyecto, @FechaCreacionProyecto);
END
GO
/****** Object:  StoredProcedure [dbo].[CProyecto_O]    Script Date: 30/10/2023 03:34:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[CProyecto_O]
AS
BEGIN
    -- Selecciona todas las columnas de la tabla
    SELECT
        IdProyecto,
        NombreProyecto,
        DescripcionProyecto,
        UbicacionProyecto,
        EstadoProyecto,
        ImagenProyecto,
        HorasEstimadas,
        FechaInicioProyecto,
        FechaFinProyecto,
        FechaCreacionProyecto
    FROM CProyecto; -- Reemplaza "TuTabla" con el nombre real de tu tabla


END
GO
USE [master]
GO
ALTER DATABASE [ControlServicioSocialDB] SET  READ_WRITE 
GO

